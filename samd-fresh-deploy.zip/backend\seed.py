import re
import uuid
import os
from backend.app import app
from backend.database import db
from backend.models.doctor import Doctor, SearchIndex

def import_data_js():
    try:
        data_path = os.path.join(os.path.dirname(__file__), 'static', 'data', 'data.js')
        with open(data_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Regex to parse the JavaScript object literals
        # Adapted from previous database_setup.py
        # This acts as a reliable parser for the specific format in data.js
        pattern = r'\{\s*id:\s*(\d+),\s*name:\s*"([^"]+)",\s*qualification:\s*"([^"]*)",\s*phone:\s*"([^"]+)",\s*hospital:\s*"([^"]*)",\s*address:\s*"([^"]*)",\s*specialty:\s*"([^"]+)",\s*lat:\s*([\d.-]+),\s*lng:\s*([\d.-]+)(?:,\s*verified:\s*(true|false))?(?:,\s*subscriptionTier:\s*"([^"]+)")?(?:,\s*featured:\s*(true|false))?'
        
        matches = re.finditer(pattern, content)
        count = 0
        
        for m in matches:
            # We ignore original ID for the primary key (using UUID) but might want to log it or store it if needed for reference
            # original_id = int(m.group(1)) 
            name = m.group(2)
            qualification = m.group(3)
            phone = m.group(4)
            hospital = m.group(5)
            address = m.group(6)
            specialty = m.group(7)
            lat = float(m.group(8))
            lng = float(m.group(9))
            verified = m.group(10) == 'true'
            # tier = m.group(11) # Not in new schema
            # featured = m.group(12) # Not in new schema
            
            # Map to new Schema
            doc = Doctor(
                id=str(uuid.uuid4()),
                name=name,
                specialty=specialty, # Using specialty directly
                experience_years=0, # Default
                rating=4.5, # Default seed rating to make them look okay? Or 0.
                review_count=0,
                verified=verified,
                phone=phone,
                whatsapp=phone, # Assume whatsapp is same as phone
                city='Surat', # Defaulting to Surat as most data is Surat
                area=address, # Using address as area loosely
                latitude=lat,
                longitude=lng,
                clinic_name=hospital,
                profile_photo_url='https://via.placeholder.com/150' # Placeholder
            )
            
            db.session.add(doc)
            db.session.flush() # get ID
            
            # Create Search Index
            search_text = f"{doc.name} {doc.specialty} {doc.clinic_name} {doc.area} {doc.city}"
            idx = SearchIndex(
                doctor_id=doc.id,
                search_text=search_text,
                city=doc.city,
                area=doc.area,
                specialty=doc.specialty,
                rating=doc.rating,
                verified=doc.verified
            )
            db.session.add(idx)
            
            count += 1
            
        db.session.commit()
        print(f"Imported {count} doctors.")
        
    except Exception as e:
        print(f"Error importing data: {e}")
        db.session.rollback()

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if Doctor.query.count() == 0:
            import_data_js()
        else:
            print("Database already populated.")
