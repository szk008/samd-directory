import uuid
from backend.app import app
from backend.database import db
from backend.models.doctor import Doctor

def seed_database():
    """Add sample doctor data"""
    
    sample_doctors = [
        {
            "name": "Dr. Rajesh Kumar",
            "specialty": "Cardiologist",
            "experience_years": 15,
            "rating": 4.8,
            "review_count": 124,
            "verified": True,
            "phone": "+91 9876543210",
            "whatsapp": "+91 9876543210",
            "city": "Surat",
            "area": "Adajan",
            "latitude": 21.1959,
            "longitude": 72.8302,
            "clinic_name": "Heart Care Clinic",
            "profile_photo_url": "https://via.placeholder.com/150"
        },
        {
            "name": "Dr. Priya Patel",
            "specialty": "Pediatrician",
            "experience_years": 10,
            "rating": 4.9,
            "review_count": 98,
            "verified": True,
            "phone": "+91 9876543211",
            "whatsapp": "+91 9876543211",
            "city": "Surat",
            "area": "Vesu",
            "latitude": 21.1458,
            "longitude": 72.7706,
            "clinic_name": "Kids Care Center",
            "profile_photo_url": "https://via.placeholder.com/150"
        },
        {
            "name": "Dr. Amit Shah",
            "specialty": "Orthopedic",
            "experience_years": 20,
            "rating": 4.7,
            "review_count": 156,
            "verified": True,
            "phone": "+91 9876543212",
            "whatsapp": "+91 9876543212",
            "city": "Surat",
            "area": "Piplod",
            "latitude": 21.2156,
            "longitude": 72.8397,
            "clinic_name": "Bone & Joint Clinic",
            "profile_photo_url": "https://via.placeholder.com/150"
        },
        {
            "name": "Dr. Sneha Desai",
            "specialty": "Dermatologist",
            "experience_years": 8,
            "rating": 4.6,
            "review_count": 87,
            "verified": False,
            "phone": "+91 9876543213",
            "whatsapp": "+91 9876543213",
            "city": "Surat",
            "area": "Citylight",
            "latitude": 21.2280,
            "longitude": 72.8777,
            "clinic_name": "Skin Solutions",
            "profile_photo_url": "https://via.placeholder.com/150"
        },
        {
            "name": "Dr. Vikram Mehta",
            "specialty": "General Physician",
            "experience_years": 12,
            "rating": 4.5,
            "review_count": 203,
            "verified": True,
            "phone": "+91 9876543214",
            "whatsapp": "+91 9876543214",
            "city": "Surat",
            "area": "Pal",
            "latitude": 21.2087,
            "longitude": 72.8326,
            "clinic_name": "Family Health Clinic",
            "profile_photo_url": "https://via.placeholder.com/150"
        }
    ]
    
    try:
        for doc_data in sample_doctors:
            doc = Doctor(
                id=str(uuid.uuid4()),
                **doc_data
            )
            db.session.add(doc)
        
        db.session.commit()
        print(f"✅ Added {len(sample_doctors)} sample doctors")
        
    except Exception as e:
        print(f"Error seeding database: {e}")
        db.session.rollback()

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if Doctor.query.count() == 0:
            seed_database()
        else:
            print("Database already populated.")
